import json, subprocess, os

CHANNELS = {
    "qarni": "https://www.youtube.com/@UstazQarniOfficial/videos",
    "rizal": "https://www.youtube.com/@UstazRizal/videos",
    "halim": "https://www.youtube.com/@UstazHalimHasan/videos",
    "adli":  "https://www.youtube.com/@UstazAdli/videos",
}

def fetch_videos(url, count=10):
    cmd = [
        "yt-dlp",
        "--dump-json",
        "--flat-playlist",
        "--playlist-end", str(count),
        url,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    videos = []
    for line in result.stdout.splitlines():
        item = json.loads(line)
        videos.append({
            "id": item["id"],
            "title": item.get("title", "Untitled"),
            "url": f"https://www.youtube.com/watch?v={item['id']}",
        })
    return videos

def main():
    os.makedirs("data", exist_ok=True)
    for ustaz, url in CHANNELS.items():
        print(f"Fetching {ustaz} videos…")
        try:
            videos = fetch_videos(url)
            with open(f"data/{ustaz}.json", "w") as f:
                json.dump(videos, f, indent=2)
        except Exception as e:
            print(f"⚠️ Failed to fetch {ustaz}: {e}")

if __name__ == "__main__":
    main()
